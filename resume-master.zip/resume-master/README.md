## My Resume

Based on the openly available LaTeX Resume templates at [RPI](http://www.rpi.edu/dept/arc/training/latex/resumes/). Download [here](https://github.com/arkn98/resume/raw/master/resume.pdf)
